const  Mongoose  = require("mongoose");

Mongoose.connect("mongodb://localhost:27017/loginData", 
{useNewUrlParser:true,useUnifiedTopology:true},function(err){
    if(err) console.log("connection to the database has failed");

    else console.log("connection to the database successfully");
});

module.exports=Mongoose;