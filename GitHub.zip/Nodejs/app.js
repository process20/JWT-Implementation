const express = require('express');
// var router = require("./controllers/employeeController.js");
// var galleryRouter = require("./controllers/galleryController");
// var router = require("./controllers/profileController");
// var web2Controller = require("./controllers/web2Controller");
// var pfeController = require("./controllers/PFEController");
// var fileRouter = require("./controllers/fileUploadDownloadController");
// var {Profile} = require("./models/Profile.js");


// var userController = require("./controllers/userController");
var authController = require("./controllers/authController");
require("./config/passportConfig"); //execute passport config file
// var passport = require("passport"); 
var app = express(); 

const cors = require('cors');
//execute db.js file
const { Mongoose } = require('./db');  //here we establish the connection to the database

// parse JSON request bodies
app.use(express.urlencoded({extended : true}));
app.use(express.json());
// to allow the request from angular
app.use(cors({ origin: '*' }));
// app.use(passport.initialize()); //to use passport for authentification
 
// the base url for all CRUD operation of employees
// /employees is the base url for CRUD operation and matches the same collection name in database
// app.use("/employees",router);
// app.use("/gallery", galleryRouter);
// app.use("/profiles", router);
// app.use("/file", fileRouter);
// app.use("/web2", web2Controller); 
// app.use("/PFE", pfeController);    //link with PFEController
// app.use("/api", userController);
app.use("/auth", authController);

app.listen(3000,function(err, res){
  console.log("server started at port : 3000");
  if(err) console.log(err);
});

// error handler
// app.use((err, req, res, next) => {
  // if (err.name === 'ValidationError') {
      // // contains one or more errors to be displayed
      // var valErrors = [];
      // Object.keys(err.errors).forEach(key => valErrors.push(err.errors[key].message));
      // res.status(422).send(valErrors)
  // }
// });

// app.get('/', function(req,res){

  // res.sendFile(__dirname+'/controllers/email.html');
// });

// app.post('/emailValidaion', function(req,res){
  // var mail = req.body.email;
  // Profile.updateOne({email:mail}, { $set: {username: "Japan"}} ,function(err,result){
    // if(err) return next(err);
    // else res.send(result);            //very important
  // });
// });

