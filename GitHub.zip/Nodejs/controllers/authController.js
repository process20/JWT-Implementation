var express = require('express');
var router = express.Router();
const auth = require("../models/auth");
var bycrypt = require('bcryptjs');
const jwt = require("jsonwebtoken");
const JWT_SECRET = "6kmgXW%nDq4ryRMHK!n*CBxhd2vTVEG5N?^SkZSApy%Qd+SWy2hnA3xyHUasKpCE%X4=-J%fGWa@wh4w7V&p^emy5SPhZC5dc+6_";
const JWT_EXP = "10m";
const verifyToken = require("../config/verifyToken");

router.post('/login', async(req, res)=>{
    console.log("login api called");
    const email= req.body.email;
    const password= req.body.password;
    console.log("user's email: "+email);
    console.log("user's password: "+password);
    await auth.findOne({email: email}).then(existUser=>{
        if(existUser){
            // console.log("exist User: "+existUser);
            bycrypt.compare(password, existUser.password, function(err, success){
                //success is a boolean variable
                if(!err){ // there are response
                    if(success){
                        // generate the token                        
                        const token = jwt.sign({_id: existUser._id}, JWT_SECRET, {expiresIn: JWT_EXP});
                        // console.log("token signed :"+token);
                        res.json({status: "ok", token: token, data: existUser});
                    }
                    else{
                        // response: false, password does not match
                        res.json({status: "wrong password, check your password", data: existUser});
                    }
                }
            });
            // console.log("user login successfully");
        }
        else{
            res.json({status: "email not found", data: "check your email"});
        }
    }).catch(error=>{
        console.log('unknown api error: '+error)
        res.json({status: "error in handling the user", data: "something went wrong"});
    })
});

router.post('/register', async(req, res)=>{
    var register = {
        username: req.body.username,
        email: req.body.email,
        password: req.body.password,
        gender: req.body.gender,
        dob: req.body.dob
    }

    const  salt = await bycrypt.genSalt(10);
    await bycrypt.hash(req.body.password, salt).then(hashedPassword=>{
        if(hashedPassword) register.password = hashedPassword;
        else console.log("error in hashing the password");
    });

    auth.create(register).then(userStoredData=>{
        if(userStoredData) {
            console.log('user stored to the database: '+userStoredData);
            res.json({status: 'ok', data: userStoredData});
        }
    }).catch(err=>{
        res.json({status: 'error', data: err});
    })
});

router.get('/dashboard', verifyToken, (req, res)=>{
    if(req._id) {
        // console.log("ok dashboard: "+req._id);
        res.json({status: 'ok', data: 'ok'});
    }
    else {
        // console.log("error in dashboard");
        res.json({status: 'ok', data: 'error'})
    };
});

module.exports = router;