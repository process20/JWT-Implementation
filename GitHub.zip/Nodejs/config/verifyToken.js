const jwt = require('jsonwebtoken');
const JWT_SECRET = "6kmgXW%nDq4ryRMHK!n*CBxhd2vTVEG5N?^SkZSApy%Qd+SWy2hnA3xyHUasKpCE%X4=-J%fGWa@wh4w7V&p^emy5SPhZC5dc+6_";

sdfldsjfkldsn = (req, res, next) => {
    console.log("verifying token process ...");
    token = req.headers['Authorization'];
    
    if(!token) {
      console.log("the token is required for authentification");
      res.status(403).send({message: "the token is required for authentification"});
      
    }
    else{
      // console.log("token: "+token);
      // get the decoded token
      const decodedToken = jwt.verify(token, JWT_SECRET);
      if(decodedToken){
        // get the user's _id because we signed the token based on user id
        req._id = decodedToken._id;
        // console.log("token id got it !!!: "+decodedToken._id);
        return next();
      }
      else{
        console.log("Token decoded failed.");
        res.status(500).json({message: 'Token decoded failed.' });
      }
    } 
}
module.exports = sdfldsjfkldsn;
