import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiCallService } from '../api-call.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

  loginForm: FormGroup;

  constructor(private apiCallService: ApiCallService, private router: Router) { }

  ngOnInit(): void {
    this.loginForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.email, Validators.pattern(this.emailRegex)]),
      password: new FormControl('', Validators.required)
    });
  }

  onSubmit(){
    if(this.loginForm.valid){
      return this.apiCallService.login(this.loginForm.value).subscribe(
        res=>{
          if((res && res['status'] === 'ok')){
            // recover the token
            localStorage.setItem('token', res['token']);
            this.router.navigate(['/dashboard']);
          }
        },
        err=>{
          console.log('we got an error: '+err);
        }
      );
    }
  }

}
