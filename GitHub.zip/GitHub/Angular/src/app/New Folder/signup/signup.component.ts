import { ApiCallService } from './../api-call.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  @ViewChild('confirmPassword', {static: false}) confirmPassword: ElementRef

  genderValues = [
    {name: "Male", value: "male"},
    {name: "Female", value: "female"},
    {name: "Others", value: "others"}
  ]
  emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

  signupForm: FormGroup;
  constructor(private apiCallService: ApiCallService, private router: Router) { }

  ngOnInit(): void {
    this.signupForm = new FormGroup({
      username: new FormControl('', Validators.required),
      email: new FormControl('', [Validators.required, Validators.email, Validators.pattern(this.emailRegex)]),
      password: new FormControl('', Validators.required),
      gender: new FormControl('', Validators.required),
      dob: new FormControl('', Validators.required)
    });
  }

  onSubmit(){
    console.log("password value: "+this.signupForm.get('password').value);
    console.log("repeat password value: "+this.confirmPassword.nativeElement.value);
    if(this.signupForm.valid && this.signupForm.get('password').value === this.confirmPassword.nativeElement.value){
      return this.apiCallService.register(this.signupForm.value).subscribe(
         res=>{
           if((res && res['status'] === 'ok')){
             this.router.navigate(['/login']);
           }
         },
         err=>{
           console.log('we got an error');
         }
       );
     }
  }

}
