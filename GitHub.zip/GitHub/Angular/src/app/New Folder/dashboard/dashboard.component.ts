import { UserstoreService } from './../../shared/userstore.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiCallService } from '../api-call.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  public fullName: string = '';
  public decodedToken: any;
  public expirationDate: any;
  public isTokenExpired: any;
  constructor(private apiCallService: ApiCallService, private router: Router, private userStoreService: UserstoreService) { }

  ngOnInit(): void {
    console.log("dashboard initialization")
    if(localStorage.getItem('token')){
      this.apiCallService.dashboard(localStorage.getItem('token')).subscribe(
        res=>{
          if(res['status'] === 'ok'){
            console.log("you are in dashboard")
          }
          else{
            console.log("something went wrong in your dashboard :"+res['status']+' , '+res['data'])
          }
        },
        err=>{
          console.log("uknown error occured")
          this.router.navigate(['/login']);
        }
      );
    }

    this.decodedToken = (this.apiCallService.decodeToken())._id;
    this.expirationDate = this.apiCallService.getTokenExpirationDate();
    this.isTokenExpired = this.apiCallService.isTokenExpired()
  }

  logout(){
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }

}
