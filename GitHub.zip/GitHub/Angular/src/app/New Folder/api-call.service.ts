import { HttpClient, HttpEvent, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Observable } from 'rxjs';
import { throwError } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ApiCallService {

  baseUrl = "http://localhost:3000/auth";
  constructor(private http: HttpClient) { }

  register(user){
    return this.http.post(this.baseUrl+'/register', user);
  }

  login(user){
    return this.http.post(this.baseUrl+'/login', user);
  }

  dashboard(token){
      const header = new HttpHeaders({
          'Content-Type': 'application/json',
          'makhlouf': `${token}`
      });
      return this.http.get(this.baseUrl+'/dashboard');
  }

  isLoggedIn(): boolean{
    return !!localStorage.getItem('token');
  }

  decodeToken(){
    const jwtHelper = new JwtHelperService();
    const token = localStorage.getItem('token');
    // jwtHelper.decodeToken(token) return json object
    // jwtHelper.decodeToken(token) depends how did you sign the token
    // console.log('email token decoded :'+jwtHelper.decodeToken(token).email);
    // console.log('username token decoded :'+jwtHelper.decodeToken(token).username);
    // console.log('token generated time (iat) token decoded :'+new Date(jwtHelper.decodeToken(token).iat).toDateString());
    // console.log('exp token decoded :'+new Date(jwtHelper.decodeToken(token).exp).toDateString());
    return jwtHelper.decodeToken(token);
  }

  getTokenExpirationDate(){
    const jwtHelper = new JwtHelperService();
    const token = localStorage.getItem('token');

    return jwtHelper.getTokenExpirationDate(token);
  }

  isTokenExpired(){
    const jwtHelper = new JwtHelperService();
    const token = localStorage.getItem('token');

    return jwtHelper.isTokenExpired(token);
  }

  // getFullNameFromToken(){
  //   if(this.decodeToken())  {
  //     console.log("the token name: "+this.decodeToken());
  //     return JSON.stringify(this.decodeToken());
  //   }
  // }

  // getRoleFromToken(){
  //   if(this.decodeToken())  {
  //     console.log("the token role: "+this.decodeToken());
  //     return this.decodeToken();
  //   }
  // }


}
