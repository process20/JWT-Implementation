import { AuthGuard } from './New Folder/auth.guard';
import { SignInComponent } from './user/sign-in/sign-in.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// import { SignUpComponent } from './user/sign-up/sign-up.component';
import { UserComponent } from './user/user.component';
import { LoginComponent } from './New Folder/login/login.component';
import { SignupComponent } from './New Folder/signup/signup.component';
import { DashboardComponent } from './New Folder/dashboard/dashboard.component';


const appRoutes: Routes = [
  // {
  //   path: 'signup', component: UserComponent,
  //   children: [{ path: '', component: SignUpComponent }]
  // },
  // {
  //   path: 'login', component: UserComponent,
  //   children: [{ path: '', component: SignInComponent}]
  // },
  // { path: 'userprofile', component: UserProfileComponent, canActivate: [AuthGuard]},
  // {
  //   path: '', redirectTo: '/login', pathMatch: 'full'
  // }

  {path: 'login', component: LoginComponent},
  {path: 'signup', component: SignupComponent},
  {path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard]},
  {path: '', redirectTo: '/login', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
