import { catchError } from 'rxjs/operators';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from "@angular/common/http";
import { Injectable } from '@angular/core';
import { tap } from 'rxjs/operators';
import { Router } from "@angular/router";
import { Observable, throwError } from 'rxjs';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

    constructor(){}

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>{
          console.log("you are in interceptor");
          // get the token from the local storage
          const token = localStorage.getItem('token');
          if(token){
            console.log("token stored to the local store: "+token);
            // modify the request header
            req = req.clone({
              setHeaders: {Authorization: `${token}`}
            });
            // handling errors
            return next.handle(req).pipe(catchError(err=>{
              console.log("something wrong in interceptor");
              if(err instanceof HttpErrorResponse){
                 console.log(err.status + ': token expired, login again');
              }
              return throwError(()=> new Error('Some Unknown Error'));
            }));
          }
          else console.log("token not provided");

    }
}


            // return next.handle(req).pipe(
            //      tap(
            //         event => { },
            //          err => {
            //              if (err) {
            //                  console.log(err.status + ': token expired, login again');
            //                  this.router.navigate(['/login']);
            //              }
            //          }
            //      )
            //  );

    //     check if there are headers set in userService
    //     if (req.headers.get('noauth'))
    //         return next.handle(req.clone());
    //     else {
    //         const clonedreq = req.clone({
    //             headers: req.headers.set("Authorization", "xxxxx " + this.userService.getToken())
    //         });
    //         handler the errors
    //         return next.handle(clonedreq).pipe(
    //             tap(
    //                 event => { },
    //                 err => {
    //                     get the auth property from verifyJwtToken
    //                     if (err.error.auth == false) {
    //                         this.router.navigate(['/login']);
    //                     }
    //                 }
    //             )
    //         );
    //     }
